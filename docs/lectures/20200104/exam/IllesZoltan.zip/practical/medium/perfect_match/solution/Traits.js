class Traits{
    constructor(nice, funny){
        if(!nice){this.nice = false;}
        if(!funny){this.funny = false;}

        this.nice=nice;
        this.funny=funny;
    }
    match(otherTrait){
        if(this.nice === otherTrait.nice && this.funny === otherTrait.funny){
            return true;
        }
        return false;
    }
}

module.exports = Traits;