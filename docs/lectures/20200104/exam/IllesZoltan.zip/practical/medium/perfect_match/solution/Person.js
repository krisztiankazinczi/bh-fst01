const trait = require('./Traits');

class Person {
    constructor(traits, preferences) {
        this.traits = traits;
        this.preferences = preferences;
    }
    recommendations(persons) {
        let arr=[];
        for (let i = 0; i < person.length; i++) {
            if ( trait.match(persons[i])){
                arr.push(persons[i]);
            }
        }
        return arr;
    }
}

module.exports = Person;