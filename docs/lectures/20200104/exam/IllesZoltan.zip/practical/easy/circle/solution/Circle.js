class Circle {
    constructor(r) {
        this.r = r;
    }
    perimeter() {
        return Math.floor(2 * Math.PI * this.r);
    }
    area() {
        return Math.floor(Math.PI * this.r * this.r);
    }
}

module.exports = Circle;