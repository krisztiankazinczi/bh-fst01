class Hero {
    constructor(name, powerLevel, life) {
        if (!name) { throw new Error('Name required!'); }
        if (!powerLevel || powerLevel < 10) { throw new Error('Power level > 10 required!'); }
        if (!life || life < 100) { throw new Error('Life > 100 required!'); }

        this.name = name;
        this.powerLevel = powerLevel;
        this.life = life;
    }
    getHeroDetails() {
        let HD = {
            name: this.name,
            powerLevel: this.powerLevel,
            life: this.life
        }
        return HD;
    }
    attack() {
        return this.powerLevel;
    }
    getHit(attackLevel) {
        if (isNaN(attackLevel)) { throw new Error('Must be a number!'); }
        this.life = this.life - attackLevel;
    }
    fury() {
        this.powerLevel = (this.powerLevel * 10 / 100) + this.powerLevel;
    }

}

module.exports = Hero;