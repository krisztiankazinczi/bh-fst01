class Person{
    constructor(name, age){
        this.name=name;
        this.age=age;
    }
    birthYear(){
        return new Date().getFullYear()-this.age;
    }
    sayHi(){
        return `Hi, my name is ${this.name} and I'm ${this.age} years old and my hobbies are coding, reading.`
    }
}

module.exports = Person;